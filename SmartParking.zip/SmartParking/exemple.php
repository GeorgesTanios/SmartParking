<?php
$user_ip = getenv('REMOTE_ADDR');
// quand je travaille sur le serveur no local je met au lieu de l ip local 127.0.0.1 -> $user_ip
$geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip='127.0.0.1'"));
$city = $geo["geoplugin_city"];
$region = $geo["geoplugin_regionName"];
$country = $geo["geoplugin_countryName"];
$latitude = $geo["geoplugin_latitude"];
$longitude = $geo["geoplugin_longitude"];

echo "City: ".$city."<br>";
echo "Region: ".$region."<br>";
echo "Country: ".$country."<br>";
echo "Latitude: ".$latitude."</br>";
echo "Longitude: ".$longitude."</br>";
/*
geoplugin_request
geoplugin_status
geoplugin_credit
geoplugin_city
geoplugin_region
geoplugin_areaCode
geoplugin_dmaCode
geoplugin_countryCode
geoplugin_countryName
geoplugin_continentCode
geoplugin_latitude
geoplugin_longitude
geoplugin_regionCode
geoplugin_regionName
geoplugin_currencyCode
geoplugin_currencySymbol
geoplugin_currencySymbol_UTF8
geoplugin_currencyConverter
*/
?>