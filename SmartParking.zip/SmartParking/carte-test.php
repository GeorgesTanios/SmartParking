<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<script src="https://maps.google.com/maps/api/js?key=AIzaSyC-DQMNpFOsCsbuY5DScXN-3xiH7amJrN4&callback=initMap" type="text/javascript"></script>
		<script async type="text/javascript">
			// On initialise la latitude et la longitude de Paris (centre de la carte)
			var lat = 48.852969;
			var lon = 2.349903;
			var map = null;
			// Fonction d'initialisation de la carte
			function initMap() {
				// Créer l'objet "map" et l'insèrer dans l'élément HTML qui a l'ID "map"
				map = new google.maps.Map(document.getElementById("map"), {
					// Nous plaçons le centre de la carte avec les coordonnées ci-dessus
					center: new google.maps.LatLng(lat, lon), 
					// Nous définissons le zoom par défaut
					zoom: 11, 
					// Nous définissons le type de carte (ici carte routière)
					mapTypeId: google.maps.MapTypeId.ROADMAP, 
					// Nous activons les options de contrôle de la carte (plan, satellite...)
					mapTypeControl: true,
					// Nous désactivons la roulette de souris
					scrollwheel: false, 
					mapTypeControlOptions: {
						// Cette option sert à définir comment les options se placent
						style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR 
					},
					// Activation des options de navigation dans la carte (zoom...)
					navigationControl: true, 
					navigationControlOptions: {
						// Comment ces options doivent-elles s'afficher
						style: google.maps.NavigationControlStyle.ZOOM_PAN 
					}
				});
			}
            
           
			window.onload = function(){
				// Fonction d'initialisation qui s'exécute lorsque le DOM est chargé
				initMap(); 
                
                
                const UserLocation = [];
                if(navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(function(position) {
                        var pos = new google.maps.LatLng(position.coords.latitude,
                                                       position.coords.longitude);
                        var marker = new google.maps.Marker({
                            position: pos,    
                            map: map,
                            title: 'Here you are',
                            draggable: true
                        });
                    });         
                }
                
            
                function parking() { // function qui retourne toutes les informations des parking dans une array    
                <?php    
                    $sql = "select * from parkings";
                    //echo"$sql";
                    $res = mysqli_query($cn,$sql);
                    $i=0;   
                    if(mysqli_num_rows($res)>0)
                    {
                        
                        // variable location qui contient les information des parkings
                        echo"var location =[";
                        while($ligne = mysqli_fetch_array($res))
                        {

                            $NomParking = $ligne['NomParking'];
                            $Ville = $ligne['Ville'];
                            $Place_Total = $ligne['Place_Total'];
                            $Nbr_voiture = $ligne['Nbr_voiture'];
                            $Longitude = $ligne['Longitude'];
                            $Latitude = $ligne['Latitude'];
                            $idParking = $ligne['Id'];  

                            $place_dispo = $Place_Total - $Nbr_voiture;
                            $TauxRemplissage = ($Nbr_voiture * 100)/$Place_Total;
                            $i++;

                            // mettre la couleure seulon le taux de remplissage
                            if( ($TauxRemplissage>=0) && ($TauxRemplissage<=60))
                            {
                                $couleur ='green';
                            }
                            else if(($TauxRemplissage > 60) && ($TauxRemplissage < 85))
                            {
                                $couleur = 'orange';
                            }
                            elseif(($TauxRemplissage >85) && ($TauxRemplissage<99) && ($place_dispo >1))
                            {
                                $couleur = 'red';
                            }
                            else
                            {
                                $couleur = 'bloque';
                            }


                            if($i == $nbrParking)
                            {
                                //array pour javascript
                                echo "['$idParking',$Latitude,$Longitude,'$NomParking',$Nbr_voiture,$place_dispo,$TauxRemplissage,'$couleur']];";
                            }
                            else
                            {   
                                //array pour javascript
                                echo "['$idParking',$Latitude,$Longitude,'$NomParking',$Nbr_voiture,$place_dispo,$TauxRemplissage,'$couleur'],";
                            }
                        }

                    }
                
                ?>
                    return location;
                } // fin du fonction parking
            
            
    //**************************************************************************************************************        
           
        // la fontion getDistanceFromLatLonInKm calcule la distance entre la location de l'utilisateur et la location de chauqe parking.                
        function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
                var R = 6371; // Radius of the earth in km
                var dLat = deg2rad(lat2-lat1);  // deg2rad below
                var dLon = deg2rad(lon2-lon1); 
                var a = 
                Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
                Math.sin(dLon/2) * Math.sin(dLon/2)
                ; 
                var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
                var d = R * c; // Distance in km
                return d;
        }

        function deg2rad(deg) {
            return deg * (Math.PI/180)
        }        
            
     //**************************************************************************************************************       
            
            
        // ici on ajoute notre point sur la carte ou se localise les parkings dans Brest avec les information               
        var infowindow = new google.maps.InfoWindow();
        
        // to get all information from the function parking
        var location = parking();
    
        for (var i = 0; i < location.length; i++)
        {
             if(location[i][6] < 90) // test si le taux de remplissage est plus petit que 90%
             {
                
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(location[i][1], location[i][2]),
                        icon: icons['parking'].icon,
                        map: map,
                        title: location[i][0]
                    });


                    //fonctiion add listener qui add les form pour chaque marker
                    google.maps.event.addListener(marker, 'click', (function (marker, i) {


                        return function () {

                             if(navigator.geolocation) {
                            navigator.geolocation.getCurrentPosition(function(position) {
                            var UserLocation = [position.coords.latitude,position.coords.longitude];


                            console.log("parkingLoc:"+location[i][1]+" / "+location[i][2]+" User:"+UserLocation[0]+" / "+UserLocation[1]);
                            // la distance entre chaque point et l'utilisateur.
                            var distance = getDistanceFromLatLonInKm(location[i][1],location[i][2],UserLocation[0],UserLocation[1]).toFixed(1);


                            // je cree le form du content que je vais l'afficher quand je clique sur chaque marker

                            var content = '<div class="info-window" >' +
                    '<h3>'+location[i][3]+'</h3>' +
                    '<div class="info-content" style="border-color:'+location[i][7]+'">' +
                    '<p>'+
                    '<br> <b> '+location[i][5]+' places Disponibles </b>'+
                            '<br> Distance: '+distance+' km '+    
                    '</p>' +
                    '<div id="myProgress"  style="width:100%; background-Color:#ddd;">'+
                    '<div id="myBar" style="width:'+location[i][6]+'%; height:30px;background-color:'+location[i][7]+'"><b>'+location[i][6].toFixed(2)+'%</b></div>'+
                    '</div>'+            
                    '</div>' +
                    '<div>'+
                    '<button style="background-color:blue;padding:0px;color:white;margin-top:5px;" value="i" id="btn_direction" latitude="'+location[i][1]+'" longitude="'+location[i][2]+'" onclick="calcRoute()"> Get Direction </button>'+ '</div>'+           
                    '</div>';

                            infowindow.setContent(content);
                            infowindow.open(map, marker);




                                 });
                             }
                        }
                    })(marker, i));  
                 
             } // end if
        }// end for
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
                 
              }


		</script>
		<style type="text/css">
			#map{ /* la carte DOIT avoir une hauteur sinon elle n'apparaît pas */
				height:400px;
			}
		</style>
		<title>Carte</title>
	</head>
	<body>
		<div id="map">
       
       

    </div>
	</body>
</html>


		