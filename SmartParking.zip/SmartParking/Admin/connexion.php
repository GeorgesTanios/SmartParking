<?php 
$cn = mysqli_connect('localhost','root','');
        
        if($cn==false)
        {
            die("Impossible d\'acceder au serveur My SQL");
        }
         mysqli_select_db($cn,'smartparking')
            or die("nom de la base de donnee est incorrecte");

        mysqli_query($cn,"SET NAMES utf8");
        mysqli_query($cn,'SET CHARACTER SET utf8');

?>