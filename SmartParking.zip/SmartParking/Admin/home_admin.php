	<!DOCTYPE html>
<html lang="en">

<head>

        <title>Smart Parking</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- connexion avec la base de donnee Smart parking -->
    <?php
        include("connexion.php");
    ?>
    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">


    <style>
         body {
            background:url(../image/brest-1.jpg) no-repeat center fixed;
            padding-top:100px;
            background-size:cover;
        }

        .navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form{
            direction: rtl;
        }
        .lbl_black{
            color:black;
        }

        .navbar {
            background-image:none;
        }

        #first-jumbo {
            text-align:center;
        }
        
        /* style pour utiliser container  plus petit ou plus grand */
        @media (min-width: 768px) {
    .container-small {
        width: 300px;
    }
    .container-large {
        width: 970px;
    } 
    } 
    @media (min-width: 992px) {
        .container-small {
            width: 500px;
        }
        .container-large {
            width: 1170px;
        } 
    } 
    @media (min-width: 1200px) {
        .container-small {
            width: 700px;
        }
        .container-large {
            width: 1500px;
        } 
    }

    .container-small, .container-large {
        max-width: 100%;
    }
        
        /*style pour le titre du contact */
         .contactPersonTitle {
        font-size: 2.5em;
        text-transform: none;
        font-weight: 300;
        color: #009add;
        }
        .contactPersonTitle {
        display: block;
        font-size: 1.5em;
        margin-block-start: 0.83em;
        margin-block-end: 0.83em;
        margin-inline-start: 0px;
        margin-inline-end: 0px;
        font-weight: bold;
        }
        
        /* pour la carte */
        #map{ /* la carte DOIT avoir une hauteur sinon elle n'apparaît pas */
				height:500px;
			}
        
        /* Pour le test c quoi la valable du parking */
        .on{
            background-color: forestgreen;
        }
        .off{
            background-color: firebrick;
        }
      
    </style>

</head>

<body>
    
    

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
    <a class="navbar-brand" href="#"><img src="../image/logo_brest_01.png"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="home_admin.php">Home</a>
                    </li>
                    <li>
                        <a href="parking.php">Parking</a>
                    </li>
                    <li>
                        <a href="https://www.brest.fr/brest-fr-accueil-3.html">Brest Metropole</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    
      
   

    <!-- div pour la carte -->
    
    <div class="container" style="padding-top:52px; padding-bottom:3px;">
        <div class="row">
            <div class="col-md-12">
                <div id="map">
			     <!-- Ici s'affichera la carte -->
                </div>
            </div>
        </div>
        <p id="demo"></p>
        
        <div id="info"></div>
    </div>

  
    
    <script>
           
     
      
    </script>
    
    <!-- /.container -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>

    
    <!-- Map Script -->
    <!-- AIzaSyC-DQMNpFOsCsbuY5DScXN-3xiH7amJrN4&callback=initMap -->
     <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCICWRjvS-tcRP0JLB0twVOmMIhpqDaoHc&callback=initMap">
    </script>
		<script async type="text/javascript">
                   
            
            
			// On initialise la latitude et la longitude de Paris (centre de la carte)  
			var lat = 48.3903;
			var lon = -4.4863;
			var map = null;
			// Fonction d'initialisation de la carte
			function initMap() {
                // directionService et directionDisplay pour trouver la route
                var directionsService = new google.maps.DirectionsService();
                var directionsDisplay = new google.maps.DirectionsRenderer();
				// Créer l'objet "map" et l'insèrer dans l'élément HTML qui a l'ID "map"
				map = new google.maps.Map(document.getElementById("map"), {
					// Nous plaçons le centre de la carte avec les coordonnées ci-dessus
					center: new google.maps.LatLng(lat, lon), 
					// Nous définissons le zoom par défaut
					zoom: 14, 
					// Nous définissons le type de carte (ici carte routière)
					mapTypeId: google.maps.MapTypeId.ROADMAP, 
					// Nous activons les options de contrôle de la carte (plan, satellite...)
					mapTypeControl: true,
					// Nous désactivons la roulette de souris
					scrollwheel: false, 
					mapTypeControlOptions: {
						// Cette option sert à définir comment les options se placent
						style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR 
					},
					// Activation des options de navigation dans la carte (zoom...)
					navigationControl: true, 
					navigationControlOptions: {
						// Comment ces options doivent-elles s'afficher
						style: google.maps.NavigationControlStyle.ZOOM_PAN 
					}
				});
                
                directionsDisplay.setMap(map);
             

           <?php
                  
                
                 $sql = "select count(*) as count from parkings";
            //echo"$sql";
            $res = mysqli_query($cn,$sql);

            if(mysqli_num_rows($res)>0)
            {
                if($ligne = mysqli_fetch_array($res))
                {
                    $nbrParking = $ligne['count'];
                }
            }
                
                $ip=$_SERVER['REMOTE_ADDR'];
                $geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip='193.52.45.31'"));
                $Usercity = $geo["geoplugin_city"];
                $Userregion = $geo["geoplugin_regionName"];
                $Usercountry = $geo["geoplugin_countryName"];
                $Userlatitude = $geo["geoplugin_latitude"];
                $Userlongitude = $geo["geoplugin_longitude"];

                //echo "City: ".$Usercity."<br>";
                //echo "Region: ".$Userregion."<br>";
                //echo "Country: ".$Usercountry."<br>";
                //echo "Latitude: ".$Userlatitude."</br>";
                //echo "Longitude: ".$Userlongitude."</br>";
                
                
                // j'ai mit c'est informations dans une variable Userlocation pour l'utiliser en bas en JavaScript pour calculer la distance entre l'utilisateur et le parking.
                
                
                echo"var Userlocation =[$Userlatitude,$Userlongitude] ;";
                
                ?>
                
                function parking() { // function qui retourne toutes les informations des parking dans une array
                    
                <?php    
                
                    $sql = "select * from parkings";
                    //echo"$sql";
                    $res = mysqli_query($cn,$sql);
                    $i=0;   
                    if(mysqli_num_rows($res)>0)
                    {
                        // variable location qui contient les information des parkings
                        echo"var location =[";
                        while($ligne = mysqli_fetch_array($res))
                        {

                            $NomParking = $ligne['NomParking'];
                            $Ville = $ligne['Ville'];
                            $Place_Total = $ligne['Place_Total'];
                            $Nbr_voiture = $ligne['Nbr_voiture'];
                            $Longitude = $ligne['Longitude'];
                            $Latitude = $ligne['Latitude'];
                            $idParking = $ligne['Id'];  

                            $place_dispo = $Place_Total - $Nbr_voiture;
                            $TauxRemplissage = ($Nbr_voiture * 100)/$Place_Total;
                            $i++;

                            // mettre la couleure seulon le taux de remplissage
                            if( ($TauxRemplissage>=0) && ($TauxRemplissage<=60))
                            {
                                $couleur ='green';
                            }
                            else if(($TauxRemplissage > 60) && ($TauxRemplissage < 85))
                            {
                                $couleur = 'orange';
                            }
                            elseif(($TauxRemplissage >85) && ($TauxRemplissage<99) && ($place_dispo >1))
                            {
                                $couleur = 'red';
                            }
                            else
                            {
                                $couleur = 'bloque';
                            }


                            if($i == $nbrParking)
                            {
                                // array pour php
                                $location[$i] = array("$idParking",$Latitude,$Longitude,'$NomParking',$Nbr_voiture,$place_dispo,$TauxRemplissage,'$couleur');
                                
                                //array pour javascript
                                echo "['$idParking',$Latitude,$Longitude,'$NomParking',$Nbr_voiture,$place_dispo,$TauxRemplissage,'$couleur']];";
                            }
                            else
                            {
                                // array pour php
                                $location[$i] = array("$idParking",$Latitude,$Longitude,'$NomParking',$Nbr_voiture,$place_dispo,$TauxRemplissage,'$couleur');
                                
                                //array pour javascript
                                echo "['$idParking',$Latitude,$Longitude,'$NomParking',$Nbr_voiture,$place_dispo,$TauxRemplissage,'$couleur'],";
                            }
                        }

                    }
                
                
                ?>
                    return location;
                } // fin du fonction parking
                
                function GetUserLocation()
                {
                    if(navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(function(position) {
                        var UserLocation = [position.coords.latitude,position.coords.longitude];
                        return UserLocation;
                        });
                    }
                    return UserLocation;
                }
                // ce lien google/mapfiles , c'est pour changer le form du markeur
                
                var iconBase = 'https://maps.google.com/mapfiles/kml/shapes/';
                var icons = {
                  parking: {
                    icon: iconBase + 'parking_lot_maps.png'
                  },
                  library: {
                    icon: iconBase + 'library_maps.png'
                  },
                  info: {
                    icon: iconBase + 'info-i_maps.png'
                  }
                };
                const UserLocation = [];
                if(navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(function(position) {
                        var pos = new google.maps.LatLng(position.coords.latitude,
                                                       position.coords.longitude);  
                        var marker = new google.maps.Marker({
                        position: pos,    
                        map: map,
                        title: 'Here you are',
                        draggable: true
                        });
                    });
                    
                }

                
// la fontion getDistanceFromLatLonInKm calcule la distance entre la location de l'utilisateur et la location de chauqe parking.                
        function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
                var R = 6371; // Radius of the earth in km
                var dLat = deg2rad(lat2-lat1);  // deg2rad below
                var dLon = deg2rad(lon2-lon1); 
                var a = 
                Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
                Math.sin(dLon/2) * Math.sin(dLon/2)
                ; 
                var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
                var d = R * c; // Distance in km
                return d;
        }

        function deg2rad(deg) {
            return deg * (Math.PI/180)
        }              
              
      
              
    
                
        // ici on ajoute notre point sur la carte ou se localise les parkings dans Brest avec les informatoi -->                
        var infowindow = new google.maps.InfoWindow();
        
        // to get all information from the function parking
        var location = parking();
    
        for (var i = 0; i < location.length; i++)
        {
            
             if(location[i][6] < 90) // test si le taux de remplissage est plus petit que 90%
             {

             
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(location[i][1], location[i][2]),
                        icon: icons['parking'].icon,
                        map: map,
                        title: location[i][0]
                    });


                    //fonctiion add listener qui add les form pour chaque marker
                    google.maps.event.addListener(marker, 'click', (function (marker, i) {


                        return function () {

                             if(navigator.geolocation) {
                            navigator.geolocation.getCurrentPosition(function(position) {
                            var UserLocation = [position.coords.latitude,position.coords.longitude];


                            console.log("parkingLoc:"+location[i][1]+" / "+location[i][2]+" User:"+UserLocation[0]+" / "+UserLocation[1]);
                            // la distance entre chaque point et l'utilisateur.
                            var distance = getDistanceFromLatLonInKm(location[i][1],location[i][2],UserLocation[0],UserLocation[1]).toFixed(1);


                            // je cree le form du content que je vais l'afficher quand je clique sur chaque marker

                            var content = '<div class="info-window" >' +
                    '<h3>'+location[i][3]+'</h3>' +
                    '<div class="info-content" style="border-color:'+location[i][7]+'">' +
                    '<p>'+
                    '<br> <b> '+location[i][5]+' places Disponibles </b>'+
                            '<br> Distance: '+distance+' km '+    
                    '</p>' +
                    '<div id="myProgress"  style="width:100%; background-Color:#ddd;">'+
                    '<div id="myBar" style="width:'+location[i][6]+'%; height:30px;background-color:'+location[i][7]+'"><b>'+location[i][6].toFixed(2)+'%</b></div>'+
                    '</div>'+            
                    '</div>' +
                    '<div>'+
                    '<button style="background-color:blue;padding:0px;color:white;margin-top:5px;" value="i" id="btn_direction" latitude="'+location[i][1]+'" longitude="'+location[i][2]+'" onclick="calcRoute()"> Get Direction </button>'+ '</div>'+           
                    '</div>';

                            infowindow.setContent(content);
                            infowindow.open(map, marker);


                                 });
                             }
                        }
                    })(marker, i)); 
                 
            } // end if
        }// end for
        

          
        }// end initMap
            
              /*
                // Attaches an info window to a marker with the provided message. When the
                // marker is clicked, the info window will open with the secret message.
                function attachSecretMessage(marker, secretMessage) {
                      var infowindow = new google.maps.InfoWindow({
                        content: secretMessage
                      });

                      marker.addListener('click', function() {
                        infowindow.open(marker.get('map'), marker);
                      });
                }
                */
                     
                    function calcRoute() {
                        
                        //var location = parking(); // on utilise la function parking pour prendre toutes les informations des parkings sous forme d'une array
                        var directionsService = new google.maps.DirectionsService();
                        let lat = event.target.getAttribute('latitude');
                        let long = event.target.getAttribute('longitude');
                        
                        var selectedIndex = document.getElementById('btn_direction').value;
                        var org = new google.maps.LatLng(lat,long);
                        var dest = new google.maps.LatLng(lat,long);
                        var request = {
                        origin: org,
                        destination: dest,
                        // Note that Javascript allows us to access the constant
                        // using square brackets and a string value as its
                        // "property."
                        travelMode: google.maps.TravelMode.DRIVING
                        };
                      directionsService.route(request, function(response, status) {
                            if (status === google.maps.DirectionsStatus.OK) {
                              directionsDisplay.setDirections(response);
                            }else {
                                console.log('Directions request failed due to ' + status);
                                }
                      });
                }//end function calcRoute()  
            
            
            
			window.onload = function(){
				// Fonction d'initialisation qui s'exécute lorsque le DOM est chargé
              
				initMap(); 
               
			};
            
            
		</script>
        
     
    
    
        <?php
    
      $sql = "select * from parkings";
            //echo"$sql";
            $res = mysqli_query($cn,$sql);
            $i=0;   
            if(mysqli_num_rows($res)>0)
            {
                // variable location qui contient les information des parkings
                while($ligne = mysqli_fetch_array($res))
                {

                    $NomParking = $ligne['NomParking'];
                    $Ville = $ligne['Ville'];
                    $Place_Total = $ligne['Place_Total'];
                    $Nbr_voiture = $ligne['Nbr_voiture'];
                    $Longitude = $ligne['Longitude'];
                    $Latitude = $ligne['Latitude'];
                    $idParking = $ligne['Id'];
                    $test = $ligne['Valable'];
                    if($test == 1)
                    {
                        $valable = "on";
                    }
                    else
                    {
                        $valable = "off";
                    }

                    $place_dispo = $Place_Total - $Nbr_voiture;
                    $TauxRemplissage = ($Nbr_voiture * 100)/$Place_Total;
                    $i++;

                    // mettre la couleure seulon le taux de remplissage
                    if( ($TauxRemplissage>=0) && ($TauxRemplissage<=60))
                    {
                        $couleur ='green';
                    }
                    else if(($TauxRemplissage > 60) && ($TauxRemplissage < 85))
                    {
                        $couleur = 'orange';
                    }
                    elseif(($TauxRemplissage >85) && ($TauxRemplissage<99) && ($place_dispo >1))
                    {
                        $couleur = 'red';
                    }
                    else
                    {
                        $couleur = 'bloque';
                    }


                    if($i == $nbrParking)
                    {
                        // array pour php
                        $location[$i] = array("$idParking",$Latitude,$Longitude,"$NomParking",$Nbr_voiture,$place_dispo,$TauxRemplissage,"$couleur","$valable");

                    }
                    else
                    {
                        // array pour php
                        $location[$i] = array("$idParking",$Latitude,$Longitude,"$NomParking",$Nbr_voiture,$place_dispo,$TauxRemplissage,"$couleur","$valable");
                    }
                }

            }
    echo "<div class='container' style='background-color:rgba(77, 160, 230, 0.2);'>";
    echo "<form action='#' method='post' >";
    for($c=1;$c<=$nbrParking;$c++)
    {
        if($location[$c][7] == "green")
        {

    ?>
    
        <div class="form-group">
             <label class="lbl_black"><?php echo $location[$c][3]?></label>
            <div class="progress">
                <div class="progress-bar progress-bar-success from-control" role="progressbar" aria-valuenow="<?php echo number_format($location[$c][6])?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo number_format($location[$c][6])?>%">
                <?php echo number_format($location[$c][6])?>%
                </div>
            </div>
            <button id = "" alt="<?php echo $location[$c][0] ?>" class="btn_on_off btn <?php echo $location[$c][8] ?>"> <?php echo $location[$c][8] ?> </button>
        </div>
    <?php
                
        } 
        if($location[$c][7] == "orange")
        {
    ?>
     <div class="form-group">
             <label class="lbl_black"><?php echo $location[$c][3]?></label>
            <div class="progress">
                <div class="progress-bar progress-bar-warning from-control" role="progressbar" aria-valuenow="<?php echo $location[$c][6]?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo number_format($location[$c][6])?>%">
                <?php echo number_format($location[$c][6])?>%
                </div>
            </div>
        </div>
    
       <?php
                
        } 
        if($location[$c][7] == "red")
        {
    ?>
     <div class="form-group">
             <label class="lbl_black"><?php echo $location[$c][3]?></label>
            <div class="progress">
                <div class="progress-bar progress-bar-danger from-control" role="progressbar" aria-valuenow="<?php echo  number_format($location[$c][6])?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo number_format($location[$c][6])?>%">
                <?php echo number_format($location[$c][6])?>%
                </div>
            </div>
        </div>
     <?php
                
        } 

        if($location[$c][7] == "bloque")
        {
     ?>
     <div class="form-group">
             <label class="lbl_black"><?php echo $location[$c][3]?></label>
            <div class="progress">
                <div class="progress-bar progress-bar-danger from-control" role="progressbar" style ="color:black" aria-valuenow="<?php echo number_format($location[$c][6])?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo number_format($location[$c][6])?>%">
                <?php echo number_format($location[$c][6])?>%
                </div>
            </div>
            <button class="btn btn-default"></button>
        </div>
    <?php
        }
    }
    echo"</div>"; // end form
    echo"</div>"; // end container
            
            
    ?>
    
        
    <!-- JQuery pour toggle le form du contact -->
    <script>
       
        
        // le premier demarrage
        // A $( document ).ready() block.
        $(document).ready(function() {
            $("#form1").hide();
            //getLocation();
            
        });
        
        //ici quand je click sur le lien contact la map disparair alors que la form du contact aparait
        $(document).ready(function(){
            $("#link_contact").click(function(){
            $("#form1").show();
            $("#map").hide();    
            });

        });
        
        //ici on ecrit le script de la boutton btn_on_off
        $(".btn_on_off").click(  function goToURL() {
            var parkingID = $(".btn_on_off").attr('alt');    
            location.href = 'home_admin.php?id='+ parkingID+;
            console.write(parkingID);

        })
        
   
    </script>   
    <!-- quand je clique sur la bouton x du form de contact us -->
    <script>
        function myFunction() {
           document.getElementById('form1').style.display='none';
           document.getElementById('map').style.display='block';
            
        }
        
       
    </script>    
    
    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    <!-- Contact Form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="../js/jqBootstrapValidation.js"></script>
    

</body>

</html>
