<!doctype html>
<html>
<head>
<title>Login Admin</title>
<meta charset="UTF-8">
<!-- add bootstrap cdn -->



    <script src="../js/jquery.js"></script>

     <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">


</head>
<?php
$con=mysqli_connect('localhost','root','','smartparking');
if($con==false) {echo "Pb de connection";}
else
{function querydb($st){
		global $con;
		return mysqli_query($con,$st);
}}

mysqli_set_charset($con,'utf8');
?>
<?php

if(isset($_REQUEST['btn_login']))
{
    $user=$_REQUEST['username'];
    $password=md5($_REQUEST['password']);
    if($user==''||$password==''){
    echo "<script>alert('Enter Username and password')</script>";
    }
    else{
        $query="select Username,Password from admin where Username='$user' and Password='$password'";
        $r=mysqli_query($con,$query);
        if(mysqli_num_rows($r)>0){
            $_SESSION['user'] = $user;
            $_SESSION['pwd'] = $password;
            header("Location:home_admin.php?");
        }
        else{
            echo "<script>alert('mot de passe ou Username pas valable')</script>";
                //echo"ليس لديك مستخدم";	
    }}
}
if(isset($_REQUEST['btn_register']))
{
	header("Location:registerAdmin.php");
}

echo"</form>";
?>
<div class="container">
    
<div class="col-md-3">
</div>
    
<div class="login-form col-md-6">
    <h1 class="title">login here</h1>
    <form>
        <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" class="form-control">
        </div>

        <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" class="form-control">
        </div>

        <input type="submit" class="btn btn-primary btn-block" value="Login" name="btn_login">

        <div style="margin-top:10px;">
            <input type="submit" class="btn btn-primary btn-block" value=" Register " name="btn_register">
        </div>
    </form>
</div>
    
<div class="col-md-3">
</div>

</div>
<!-- add some css styles -->

<style type="text/css">
body {
    background:url(../image/brest-1.jpg) no-repeat center fixed;
    padding-top:100px;
    background-size:cover;
}


.login-form{
	margin-top: 60px;
	box-shadow:0px 0px 10px 1px grey;
	border-radius:5px;
	padding-bottom:20px;
	background:light green;
}
.title{
	background: #007bbf;
	padding:10px;
	text-align:center;
	color:#fff;
	border-radius:0px 0px 10px 10px;
}
</style>
</html>



 <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    <!-- Contact Form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="../js/jqBootstrapValidation.js"></script>