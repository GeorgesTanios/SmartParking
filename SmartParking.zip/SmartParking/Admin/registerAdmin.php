<!doctype html>
<html>
<head>
<title>Register Admin</title>
<meta charset="UTF-8">
<!-- add bootstrap cdn -->

<link  rel="stylesheet" href="../css/bootstrap.min.css" crossorigin="anonymous">
<script src="../js/jquery.js"></script>


</head>
<?php
     include("connexion.php");
?>
<?php

if(isset($_REQUEST['btn_Login']))
{
    header("location:index.php");
}

if(isset($_REQUEST['btn_Register']))
{
    $username = $_REQUEST['username'];
    $password = md5($_REQUEST['password1']);
    $password_confim = md5($_REQUEST['password2']);
    $nom = $_REQUEST['nom'];
    $prenom = $_REQUEST['prenom'];
    $telephone = $_REQUEST['telephone'];
    $email = $_REQUEST['email'];
    
    if($username!="" &&$password!="" &&$password_confim!="" &&$nom!="" &&$prenom!="" &&$telephone!="" &&$email!="")
    {
        $sql="INSERT INTO `admin` (`AdminID`, `Username`, `Password`, `Prenom`, `Nom`, `Telephone`, `Email`)VALUES (NULL, '$username', '$password', '$prenom', '$nom', '$telephone', '$email');";
        //echo $sql;
        $res = mysqli_query($cn,$sql);
        if(mysqli_affected_rows($cn)>0)
        {
            echo"<script> alert('these new candidate has been added successfully');</script>";

            //header("location:../liste_candidate.php");
        }
    }

}

//echo"<form>";
?>
<div class="container">
    
<div class="col-md-3">
</div>
    
<div class="login-form col-md-6" style="background-color:rgba(77, 160, 230, 0.2);">
    <h1 class="title">Register here</h1>
    <form id="form1" method="post">
        <div class="form-group">
            <label class="lbl_black">Username</label>
            <input type="text" name="username" id="username" class="form-control" data-msg-required="<p style='color:#E62C2C;font-size:12px;'>this field is required.<p>" required>
        </div>

        <div class="form-group">
            <label class="lbl_black">Password</label>
            <input type="password" name="password1"  id="password1" class="form-control" data-msg-required="<p style='color:red;font-size:12px;'>this field is required.<p>" required> 
        </div>
        
        <div class="form-group">
            <label class="lbl_black">Confirm Password</label>
            <input type="password" name="password2" id="password2" class="form-control" data-msg-required="<p style='color:red;font-size:12px;'>this field is required.<p>" data-msg-equalTo="<p style='color:#E62C2C;font-size:12px;'>please enter the same password.<p>" data-rule-equalTo="#password1" required> 
        </div>
        
        <div class="form-group">
            <label class="lbl_black">Nom</label>
            <input type="text" id="nom" name="nom" class="form-control" data-msg-required="<p style='color:#E62C2C;font-size:12px;'>this field is required.<p>" required>
        </div>
        
        <div class="form-group">
            <label class="lbl_black">Prenom</label>
            <input type="text" id="prenom" name="prenom" data-msg-required="<p style='color:#E62C2C;font-size:12px;'>this field is required.<p>" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label class="lbl_black">Numero Telephone</label>
            <input type="text" name="telephone" id="telephone" class="form-control" data-msg-required="<p style='color:#E62C2C;font-size:12px;'>this field is required.<p>" required>
        </div>
        
        <div class="form-group">
            <label class="lbl_black">Email</label>
            <input type="text" name="email" id="email" class="form-control" data-msg-required="<p style='color:#E62C2C;font-size:12px;'>this field is required.<p>" data-rule-email="true" data-msg-email="<p style='color:#E62C2C;font-size:12px;'>enter an email adress please.<p>" required>
        </div>
        <div>
            <input type="submit"  class="btn btn-primary btn-block" value="Register" name="btn_Register">
        </div>
         <div>
            <input type="button" onclick="Redirect_login()" style="margin-top:5px;"  class="btn btn-primary btn-block" value="Login" name="btn_Login">
        </div> 
       
    </form>
</div>
    
<div class="col-md-3">
</div>

</div>
<!-- add some css styles -->

<style type="text/css">
body {
    background:url(../image/brest-1.jpg) no-repeat center fixed;
    padding-top:100px;
    background-size:cover;
}

.lbl_black{
    color:black;
}    

.login-form{
	margin-top: 60px;
	box-shadow:0px 0px 10px 1px grey;
	border-radius:5px;
	padding-bottom:20px;
	background:light green;
}
.title{
	background: #007bbf;
	padding:10px;
	text-align:center;
	color:#fff;
	border-radius:0px 0px 10px 10px;
}
</style>
</html>


<script type="text/javascript" src="//code.jquery.com/jquery-2.1.0.js"></script>
    <script type="text/javascript" src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
	
	<script type="text/javascript">
		$('#form1').validate();
        function Redirect_login() {
          location.replace("index.php");
        }
	</script> 



 <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jQueryValidation.min.js"> </script>

    <!-- Contact Form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="../js/jqBootstrapValidation.js"></script>