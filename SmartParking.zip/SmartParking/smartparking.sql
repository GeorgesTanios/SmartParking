-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2019 at 07:49 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartparking`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AdminID` int(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Prenom` varchar(255) NOT NULL,
  `Nom` varchar(255) NOT NULL,
  `Telephone` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`AdminID`, `Username`, `Password`, `Prenom`, `Nom`, `Telephone`, `Email`) VALUES
(2, 'georges1', '0aa6c0f0ee9891c695b7e65fcda86395', 'Georges', 'TANIOS', 783897899, 'georges.tanios@icloud.com');

-- --------------------------------------------------------

--
-- Table structure for table `parkings`
--

CREATE TABLE `parkings` (
  `Id` int(11) NOT NULL,
  `NomParking` varchar(255) NOT NULL,
  `Latitude` double NOT NULL,
  `Longitude` double NOT NULL,
  `Address` varchar(500) NOT NULL,
  `Ville` varchar(255) NOT NULL,
  `Place_Total` double NOT NULL,
  `Nbr_voiture` double NOT NULL,
  `Valable` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `parkings`
--

INSERT INTO `parkings` (`Id`, `NomParking`, `Latitude`, `Longitude`, `Address`, `Ville`, `Place_Total`, `Nbr_voiture`, `Valable`) VALUES
(1, 'Parking1', 48.3903, -4.4863, '2 rue ...', 'Brest', 50, 5, 1),
(2, 'Parking2', 48.3903, -4.47, '1 rue ...', 'Brest', 60, 10, 1),
(3, 'Parking3', 48.3905, -4.44, '3 rue ...', 'Brest', 120, 13, 1),
(4, 'Parking4', 48.389, -4.45, '4 rue ...', 'Brest', 80, 70, 1),
(5, 'Parking5', 48.3915, -4.6, '5 rue ...', 'Brest', 90, 60, 1),
(6, 'Parking6', 48.8164, 2.4937, '2 rue Frlsnf', 'Brest', 100, 62, 1),
(7, 'Parking 7', 48.3899, -4.483, '2 rue francois verny', 'Brest', 35, 35, 1);

-- --------------------------------------------------------

--
-- Table structure for table `parking_info`
--

CREATE TABLE `parking_info` (
  `IdParking` int(11) NOT NULL,
  `date` date NOT NULL,
  `NbrVoitureActuelle` int(11) NOT NULL,
  `NbrVoitureTotal` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AdminID`);

--
-- Indexes for table `parkings`
--
ALTER TABLE `parkings`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `parkings`
--
ALTER TABLE `parkings`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
