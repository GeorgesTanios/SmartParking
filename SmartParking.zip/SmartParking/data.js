var spaceData;
var x = 0;

function setup(){
//    loadJSON("URL ", goData);
    loadJSON("birds.json", goData,'jsonp');
}


function goData(data) {
    spaceData = data;
}
function draw(){
    background(0);
        println(data);
    if (spaceData)
    {
        for( var i =0 ; i< data.number; i++){
            fill(255);
            ellipse(random(width), random(height), 16, 16)
        }
    }
    stroke(255);
    line(x, 0, x, height);
    x = x + 1;
    if (x > width) {
        x = 0;
    }
}