<?php
//    $jsonData = file_get_contents("employee.json");
//    $json = json_decode($jsonData,true);
//
//    echo $json['employee'][1]['salary'];
//    echo "<br>";
//    echo "count data :".count($json['employee']);// this return the numbers of emplyees


//********************************
//receive the JSON Post data
$ttndtajs = json_decode( file_get_contents('php '))
//*****************************
    
//*********************************
    
?>