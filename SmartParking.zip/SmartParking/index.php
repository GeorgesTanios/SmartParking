<?php
    header("Location:./Publique");
?>