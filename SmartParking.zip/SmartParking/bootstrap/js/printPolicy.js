function printPolicy(divID){
var sWidth =  screen.availWidth;
var sHeight = screen.availHeight;

var a = window.open('','print','scrollbars=yes,width=800,height=10,left='+((sWidth/2)-350)+',top='+((sHeight/2)-130));
a.document.write('<html><head><link href="CSS/style.css" rel="stylesheet" type="text/css" /></head><body  topmargin="0" leftmargin="0">');
a.document.write(document.getElementById(divID).innerHTML);
a.document.write('</body></html>');
a.document.close();
a.print();
a.close();
}

function printVignette(divID){
var sWidth =  screen.availWidth;
var sHeight = screen.availHeight;

var a = window.open('','print','scrollbars=yes,width=800,height=10,left='+((sWidth/2)-350)+',top='+((sHeight/2)-130));
a.document.write('<html><head><link href="CSS/style.css" rel="stylesheet" type="text/css" /></head><body  topmargin="0" leftmargin="0">');
a.document.write(document.getElementById(divID).innerHTML);
a.document.write('</body></html>');
a.document.close();
a.print();
a.close();
}