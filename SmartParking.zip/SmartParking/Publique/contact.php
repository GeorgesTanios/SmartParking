	<!DOCTYPE html>
<html lang="en">

<head>

        <title>Smart Parking</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Map je dois encore mettre une Api key pour la map -->
   
    <style>
        .navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form{
            direction: rtl;
        }
        h2 {
        font-size: 2.5em;
        text-transform: none;
        font-weight: 300;
        color: #009add;
        }
        h2 {
    display: block;
    font-size: 1.5em;
    margin-block-start: 0.83em;
    margin-block-end: 0.83em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;
    font-weight: bold;
        }
    
    </style>

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
    <a class="navbar-brand" href="#"><img src="../image/logo_brest_01.png"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="#">Parking</a>
                    </li>
                    <li>
                        <a href="#">Brest Metropole</a>
                    </li>
                    
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    
    <div class="container" style="margin-right:auto;margin-left:auto; padding-left:200px;padding-top:150px;">
        <h2 class="contactPersonTitle">Contact</h2>
        <br>
       <div class="item contactPerson">
    
		<div class="wrap">
			

            <b style="sixe:10px;margin-bottom:10px;">Brest métropole</b>
            <br><br>
			<hr style="border-top: dotted 2px;" />
            <br>
		</div>
	
	
		
			<div class="address">
				<p>Hôtel de métropole - 24, rue Coat-ar-Guéven - CS 73826</p>
				<p>29238</p>
				<p>Brest Cedex 2</p>
			</div>
		<br><br>
           <hr style="border-top: dotted 2px;" />
           <br>
	
	
			<div class="contacts">
				<ul>
					
						<li class="icon2 phone"><a href="tel:0298335050">02 98 33 50 50</a></li>
					
					
					
					<li class="icon2 email"><a href="javascript:linkTo_UnCryptMailto('nbjmup+dpoubduAcsftu.nfuspqpmf/gs');">contact@brest-metropole.fr</a></li>
				</ul>
			</div>
		
	
</div>
        <div id="c5063" class="colPos0 setPos isHidden0"><div class="csc-textpic-text"><p class="bodytext"><strong>Accueil au guichet </strong>:&nbsp;Lundi au Vendredi de 7h45 à 18h30 (17h30 en été)
</p>
<p class="bodytext"><strong>Accueil téléphonique </strong>au 02 98 33 50 50<br>Lundi au Vendredi de 8h /18h -&nbsp;Samedi 8h30/12h30</p></div></div>
        
    </div>
    
    
    <!-- /.container -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>

    
    <!-- Map Script -->
     <script src="https://maps.google.com/maps/api/js?key=[AJOUTEZ_VOTRE_CLE_API_ICI]" type="text/javascript"></script>
		<script async type="text/javascript">
			// On initialise la latitude et la longitude de Paris (centre de la carte)
			var lat = 48.852969;
			var lon = 2.349903;
			var map = null;
			// Fonction d'initialisation de la carte
			function initMap() {
				// Créer l'objet "map" et l'insèrer dans l'élément HTML qui a l'ID "map"
				map = new google.maps.Map(document.getElementById("map"), {
					// Nous plaçons le centre de la carte avec les coordonnées ci-dessus
					center: new google.maps.LatLng(lat, lon), 
					// Nous définissons le zoom par défaut
					zoom: 11, 
					// Nous définissons le type de carte (ici carte routière)
					mapTypeId: google.maps.MapTypeId.ROADMAP, 
					// Nous activons les options de contrôle de la carte (plan, satellite...)
					mapTypeControl: true,
					// Nous désactivons la roulette de souris
					scrollwheel: false, 
					mapTypeControlOptions: {
						// Cette option sert à définir comment les options se placent
						style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR 
					},
					// Activation des options de navigation dans la carte (zoom...)
					navigationControl: true, 
					navigationControlOptions: {
						// Comment ces options doivent-elles s'afficher
						style: google.maps.NavigationControlStyle.ZOOM_PAN 
					}
				});
			}
			window.onload = function(){
				// Fonction d'initialisation qui s'exécute lorsque le DOM est chargé
				initMap(); 
			};
		</script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    <!-- Contact Form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="../js/jqBootstrapValidation.js"></script>
    

</body>

</html>
