	<!DOCTYPE html>
<html lang="en">

<head>

        <title>Smart Parking</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- connexion avec la base de donnee Smart parking -->
    <?php
        include("connexion.php");
    ?>
    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">


    <style>
         body {
            background:url(../image/brest-1.jpg) no-repeat center fixed;
            padding-top:100px;
            background-size:cover;
        }

        .navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form{
            direction: rtl;
        }
      
        .navbar {
            background-image:none;
        }

        #first-jumbo {
            text-align:center;
        }
        
        /* style pour utiliser container  plus petit ou plus grand */
        @media (min-width: 768px) {
    .container-small {
        width: 300px;
    }
    .container-large {
        width: 970px;
    } 
    } 
    @media (min-width: 992px) {
        .container-small {
            width: 500px;
        }
        .container-large {
            width: 1170px;
        } 
    } 
    @media (min-width: 1200px) {
        .container-small {
            width: 700px;
        }
        .container-large {
            width: 1500px;
        } 
    }

    .container-small, .container-large {
        max-width: 100%;
    }
        
        /*style pour le titre du contact */
         .contactPersonTitle {
        font-size: 2.5em;
        text-transform: none;
        font-weight: 300;
        color: #009add;
        }
        .contactPersonTitle {
        display: block;
        font-size: 1.5em;
        margin-block-start: 0.83em;
        margin-block-end: 0.83em;
        margin-inline-start: 0px;
        margin-inline-end: 0px;
        font-weight: bold;
        }
        
        /* pour la carte */
        #map{ /* la carte DOIT avoir une hauteur sinon elle n'apparaît pas */
				height:500px;
			}
    </style>

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
    <a class="navbar-brand" href="#"><img src="../image/logo_brest_01.png"></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="parking.php">Parking</a>
                    </li>
                    <li>
                        <a href="https://www.brest.fr/brest-fr-accueil-3.html">Brest Metropole</a>
                    </li>
                    
                    <li>
                        <a href="#" id="link_contact">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    
    <!-- test du form du contact -->
    <form id="form1">
        <div class="container container-small" style="margin-right:auto;margin-left:auto; padding-left:80px;padding-top:50px;padding-right:60px;padding-bottom:30px; background:white;">
        
        <span onclick="myFunction()" class="close" title="Close Modal" style="padding-bottom:50px;">&times;</span>    
        <h2 class="contactPersonTitle">Contact</h2>
        <br>
       <div class="item contactPerson">
    
		<div class="wrap">
			

            <b style="sixe:10px;margin-bottom:10px;">Brest métropole</b>
            <br><br>
			<hr style="border-top: dotted 2px;" />
            <br>
		</div>
	
	
		
			<div class="address">
				<p>Hôtel de métropole - 24, rue Coat-ar-Guéven - CS 73826</p>
				<p>29238</p>
				<p>Brest Cedex 2</p>
			</div>
		<br><br>
           <hr style="border-top: dotted 2px;" />
           <br>
	
	
			<div class="contacts">
				<ul>
					
						<li class="icon2 phone"><a href="tel:0298335050">02 98 33 50 50</a></li>
					
					
					
					<li class="icon2 email"><a href="javascript:linkTo_UnCryptMailto('nbjmup+dpoubduAcsftu.nfuspqpmf/gs');">contact@brest-metropole.fr</a></li>
				</ul>
			</div>
		
	
</div>
        <div id="c5063" class="colPos0 setPos isHidden0"><div class="csc-textpic-text"><p class="bodytext"><strong>Accueil au guichet </strong>:&nbsp;Lundi au Vendredi de 7h45 à 18h30 (17h30 en été)
</p>
<p class="bodytext"><strong>Accueil téléphonique </strong>au 02 98 33 50 50<br>Lundi au Vendredi de 8h /18h -&nbsp;Samedi 8h30/12h30</p></div></div>
       
    </div>
             </form>
            
    

   

    <!-- div pour la carte -->
    
    <div class="container" style="padding-top:52px; padding-bottom:3px;">
        <div id="map">
			<!-- Ici s'affichera la carte -->
		</div>
        <p id="demo"></p>
        
        <div id="info"></div>
    </div>

  
    
    <script>
           
     
      
    </script>
    
    <!-- /.container -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>

    
    <!-- Map Script -->
    <!-- AIzaSyDS4NOT60PIVTi3V2x6TfJkSZxv-MvcGrA=initMap -->
     <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDS4NOT60PIVTi3V2x6TfJkSZxv-MvcGrA&callback=initMap">
    </script>
		<script async type="text/javascript">
                    
            
			// On initialise la latitude et la longitude de Paris (centre de la carte)  
			var lat = 48.3903;
			var lon = -4.4863;
			var map = null;
			// Fonction d'initialisation de la carte
			function initMap() {
                // directionService et directionDisplay pour trouver la route
                var directionsService = new google.maps.DirectionsService();
                var directionsDisplay = new google.maps.DirectionsRenderer();
				// Créer l'objet "map" et l'insèrer dans l'élément HTML qui a l'ID "map"
				map = new google.maps.Map(document.getElementById("map"), {
					// Nous plaçons le centre de la carte avec les coordonnées ci-dessus
					center: new google.maps.LatLng(lat, lon), 
					// Nous définissons le zoom par défaut
					zoom: 14, 
					// Nous définissons le type de carte (ici carte routière)
					mapTypeId: google.maps.MapTypeId.ROADMAP, 
					// Nous activons les options de contrôle de la carte (plan, satellite...)
					mapTypeControl: true,
					// Nous désactivons la roulette de souris
					scrollwheel: false, 
					mapTypeControlOptions: {
						// Cette option sert à définir comment les options se placent
						style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR 
					},
					// Activation des options de navigation dans la carte (zoom...)
					navigationControl: true, 
					navigationControlOptions: {
						// Comment ces options doivent-elles s'afficher
						style: google.maps.NavigationControlStyle.ZOOM_PAN 
					}
				});
                
                directionsDisplay.setMap(map);
             
           <?php
                                  
            $sql = "select count(*) as count from parkings";
            //echo"$sql";
            $res = mysqli_query($cn,$sql);

            if(mysqli_num_rows($res)>0)
            {
                if($ligne = mysqli_fetch_array($res))
                {
                    $nbrParking = $ligne['count'];
                }
            }
                
                $ip=$_SERVER['REMOTE_ADDR'];
                $geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip='193.52.45.31'"));
                $Usercity = $geo["geoplugin_city"];
                $Userregion = $geo["geoplugin_regionName"];
                $Usercountry = $geo["geoplugin_countryName"];
                $Userlatitude = $geo["geoplugin_latitude"];
                $Userlongitude = $geo["geoplugin_longitude"];

                          
                // j'ai mit c'est informations dans une variable Userlocation pour l'utiliser en bas en JavaScript pour calculer la distance entre l'utilisateur et le parking.
                
                echo"var Userlocation =[$Userlatitude,$Userlongitude] ;";
                
                ?>
                
                function parking() { // function qui retourne toutes les informations des parking dans une array
                    
                <?php    
                
                    $sql = "select * from parkings";
                    //echo"$sql";
                    $res = mysqli_query($cn,$sql);
                    $i=0;   
                    if(mysqli_num_rows($res)>0)
                    {
                        
                        // variable location qui contient les information des parkings
                        echo"var location =[";
                        while($ligne = mysqli_fetch_array($res))
                        {

                            $NomParking = $ligne['NomParking'];
                            $Ville = $ligne['Ville'];
                            $Place_Total = $ligne['Place_Total'];
                            $Nbr_voiture = $ligne['Nbr_voiture'];
                            $Longitude = $ligne['Longitude'];
                            $Latitude = $ligne['Latitude'];
                            $idParking = $ligne['Id'];  

                            $place_dispo = $Place_Total - $Nbr_voiture;
                            $TauxRemplissage = ($Nbr_voiture * 100)/$Place_Total;
                            $i++;

                            // mettre la couleure seulon le taux de remplissage
                            if( ($TauxRemplissage>=0) && ($TauxRemplissage<=60))
                            {
                                $couleur ='green';
                            }
                            else if(($TauxRemplissage > 60) && ($TauxRemplissage < 85))
                            {
                                $couleur = 'orange';
                            }
                            elseif(($TauxRemplissage >85) && ($TauxRemplissage<99) && ($place_dispo >1))
                            {
                                $couleur = 'red';
                            }
                            else
                            {
                                $couleur = 'bloque';
                            }


                            if($i == $nbrParking)
                            {
                                //array pour javascript
                                echo "['$idParking',$Latitude,$Longitude,'$NomParking',$Nbr_voiture,$place_dispo,$TauxRemplissage,'$couleur']];";
                            }
                            else
                            {   
                                //array pour javascript
                                echo "['$idParking',$Latitude,$Longitude,'$NomParking',$Nbr_voiture,$place_dispo,$TauxRemplissage,'$couleur'],";
                            }
                        }

                    }
                
                ?>
                    return location;
                } // fin du fonction parking
                
                
                // fontion pour trouver la location du personne qui utilise le site web
                function GetUserLocation()
                {
                    if(navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(function(position) {
                        var UserLocation = [position.coords.latitude,position.coords.longitude];
                        return UserLocation;
                        });
                    }
                    return UserLocation;
                }
                // ce lien google/mapfiles , c'est pour changer le form du markeur
                
                var iconBase = 'https://maps.google.com/mapfiles/kml/shapes/';
                var icons = {
                  parking: {
                    icon: iconBase + 'parking_lot_maps.png'
                  },
                  library: {
                    icon: iconBase + 'library_maps.png'
                  },
                  info: {
                    icon: iconBase + 'info-i_maps.png'
                  }
                };
                const UserLocation = [];
                if(navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(function(position) {
                        var pos = new google.maps.LatLng(position.coords.latitude,
                                                       position.coords.longitude);
                        var marker = new google.maps.Marker({
                        position: pos,    
                        map: map,
                        title: 'Here you are',
                        draggable: true
                        });
                    });         
                }

        //*************************************************************************************************************       
        // la fontion getDistanceFromLatLonInKm calcule la distance entre la location de l'utilisateur et la location de chauqe parking.                
        function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
                var R = 6371; // Radius of the earth in km
                var dLat = deg2rad(lat2-lat1);  // deg2rad below
                var dLon = deg2rad(lon2-lon1); 
                var a = 
                Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
                Math.sin(dLon/2) * Math.sin(dLon/2)
                ; 
                var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
                var d = R * c; // Distance in km
                return d;
        }

        function deg2rad(deg) {
            return deg * (Math.PI/180)
        }              
              
      
              
    //********************************************************************************************************
                
        // ici on ajoute notre point sur la carte ou se localise les parkings dans Brest avec les informatoi -->                
        var infowindow = new google.maps.InfoWindow();
        
        // to get all information from the function parking
        var location = parking();
    
        for (var i = 0; i < location.length; i++)
        {
             if(location[i][6] < 90) // test si le taux de remplissage est plus petit que 90%
             {
                
                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(location[i][1], location[i][2]),
                        icon: icons['parking'].icon,
                        map: map,
                        title: location[i][0]
                    });

                    //fonction add listener qui add les form pour chaque marker
                    google.maps.event.addListener(marker, 'click', (function (marker, i) {

                        return function () {

                             if(navigator.geolocation) {
                            navigator.geolocation.getCurrentPosition(function(position) {
                            var UserLocation = [position.coords.latitude,position.coords.longitude];


                            console.log("parkingLoc:"+location[i][1]+" / "+location[i][2]+" User:"+UserLocation[0]+" / "+UserLocation[1]);
                            // la distance entre chaque point et l'utilisateur.
                            var distance = getDistanceFromLatLonInKm(location[i][1],location[i][2],UserLocation[0],UserLocation[1]).toFixed(1);


                            // je cree le form du content que je vais l'afficher quand je clique sur chaque marker

                            var content = '<div class="info-window" >' +
                    '<h3>'+location[i][3]+'</h3>' +
                    '<div class="info-content" style="border-color:'+location[i][7]+'">' +
                    '<p>'+
                    '<br> <b> '+location[i][5]+' places Disponibles </b>'+
                            '<br> Distance: '+distance+' km '+    
                    '</p>' +
                    '<div id="myProgress"  style="width:100%; background-Color:#ddd;">'+
                    '<div id="myBar" style="width:'+location[i][6]+'%; height:30px;background-color:'+location[i][7]+'"><b>'+location[i][6].toFixed(2)+'%</b></div>'+
                    '</div>'+            
                    '</div>' +
                    '<div>'+
                    '<button style="background-color:blue;padding:0px;color:white;margin-top:5px;" value="i" id="btn_direction" latitude="'+location[i][1]+'" longitude="'+location[i][2]+'" onclick="calcRoute()"> Get Direction </button>'+ '</div>'+           
                    '</div>';

                            infowindow.setContent(content);
                            infowindow.open(map, marker);




                                 });
                             }
                        }
                    })(marker, i));  
                 
             } // end if
        }// end for
        

          
        }// end initMap
            
              /*
                // Attaches an info window to a marker with the provided message. When the
                // marker is clicked, the info window will open with the secret message.
                function attachSecretMessage(marker, secretMessage) {
                      var infowindow = new google.maps.InfoWindow({
                        content: secretMessage
                      });

                      marker.addListener('click', function() {
                        infowindow.open(marker.get('map'), marker);
                      });
                }
                */
                     
                    function calcRoute() {
                        
                        //var location = parking(); // on utilise la function parking pour prendre toutes les informations des parkings sous forme d'une array
                        var directionsService = new google.maps.DirectionsService();
                        let lat = event.target.getAttribute('latitude');
                        let long = event.target.getAttribute('longitude');
                        console.log('latitud:'+lat+ ' longitude:'+long);
                        
                        var selectedIndex = document.getElementById('btn_direction').value;
                        var org = new google.maps.LatLng(lat,long);
                        var dest = new google.maps.LatLng(lat,long);
                        var request = {
                        origin: org,
                        destination: dest,
                        // Note that Javascript allows us to access the constant
                        // using square brackets and a string value as its
                        // "property."
                        travelMode: google.maps.TravelMode.DRIVING
                        };
                      directionsService.route(request, function(response, status) {
                            if (status === google.maps.DirectionsStatus.OK) {
                              directionsDisplay.setDirections(response);
                            }else {
                                console.log('Directions request failed due to ' + status);
                                }
                      });
                }//end function calcRoute()  
            
            
            
			window.onload = function(){
				// Fonction d'initialisation qui s'exécute lorsque le DOM est chargé
              
				initMap(); 
               
			};
            
            
		</script>
    
    <!-- JQuery pour toggle le form du contact -->
    <script>
        // le premier demarrage
        // A $( document ).ready() block.
        $(document).ready(function() {
            $("#form1").hide();
            //getLocation();
            
        });
        
        //ici quand je click sur le lien contact la map disparair alors que la form du contact aparait
    $(document).ready(function(){
        $("#link_contact").click(function(){
        $("#form1").show();
        $("#map").hide();    
        });
        
    });
        
   
    </script>
    
    
    <!-- quand je clique sur la bouton x du form de contact us -->
    <script>
        function myFunction() {
           document.getElementById('form1').style.display='none';
           document.getElementById('map').style.display='block';
            
        }
        
       
    </script>    
    
    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    <!-- Contact Form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js"></script>
    <script src="../js/jqBootstrapValidation.js"></script>
    

</body>

</html>
